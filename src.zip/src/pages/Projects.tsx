import React, { useState } from "react";
import styled from "styled-components";

import imgLegal from "../assets/test.jpg";
import imgDocs from "../assets/test.jpg";
import imgLearn from "../assets/test.jpg";
import imgDissertation from "../assets/test.jpg";

type Tech = { nameTech: string };
type Project = {
  img: string;
  name: string;
  des: string;
  tech: Tech[];
  linkLive?: string;
  linkGit?: string;
  member: string;
  role: string;
  result: string;
};

const PROJECTS: Project[] = [
  {
    img: imgLegal,
    name: "CodeHeroes Legal System, 2023",
    des: "The system allows users to look up laws and answer intelligent questions about the law",
    tech: [{ nameTech: "ReactJs" }, { nameTech: "Python Flask" }, { nameTech: "Netlify" }, { nameTech: "Docker, Jenkins" }],
    linkLive: "https://hethongphapluatcodeheroes.netlify.app/",
    linkGit: "https://github.com/duchoaang/LegalKnowledgeBot",
    member: "3",
    role: "Full-stack",
    result:
      "Improve Python Flask skills, know use Netlify to deploy system, know how to use Docker, Jenkins to build CI/CD system.",
  },
  {
    img: imgDocs,
    name: "“Ba To Pho” Document, 2023",
    des: "A project that allows users to view, post, favorite, and comment on documents, and register.",
    tech: [{ nameTech: "ReactJs" }, { nameTech: "Python Flask" }, { nameTech: "Figma" }],
    linkLive: "",
    linkGit: "https://github.com/duchoaang/Ba_To_Pho",
    member: "4",
    role:
      "Front-end, Use ReactJs to create a view of the main page, register, profile, and list document. Call API into back-end to get info user, document and handle data from back-end response, allow users to login with Google.",
    result:
      "Improve ReactJs skills, know to optimize the system with ReactJs, know how to integrate Google login.",
  },
  {
    img: imgLearn,
    name: "CodeHeros Learning System, 2023",
    des: "A project that allows users to view score statistics, do exercises and receive notifications from administrators",
    tech: [{ nameTech: "React Native" }, { nameTech: "Java Spring Boot" }, { nameTech: "Bootstrap, React-paper" }],
    linkLive: "",
    linkGit: "https://github.com/duchoaang/backend_quanlyhoctap",
    member: "1",
    role:
      "Full-stack, use React Native to create front-end for project. And use Java Spring Boot create RESTful API , manager interface for admin. Use Jwt for user authentication and user authorization.",
    result:
      "Learn React Native , know about Spring, and Spring framework - Spring Boot, Spring Security, JWT, create RESTful API with Java",
  },
  {
    img: imgDissertation,
    name: "Dissertation System, 2023",
    des: "This is a project that allows user to view, and register for dissertation.",
    tech: [{ nameTech: "React Native" }, { nameTech: "Java Spring MVC" }, { nameTech: "Material UI, Firebase" }],
    linkLive: "",
    linkGit: "https://github.com/duchoaang/JavaProject",
    member: "2",
    role:
      "Front-end, use React create user interface, login Google. Call API and get response from back-end, integrate real-time chat with Fireclound.",
    result:
      "Improve ReactJs skills, know to use Firebase integrate real-time chat for users, know about SEO for website.",
  },
];

const Projects: React.FC = () => {
  const [flipped, setFlipped] = useState<boolean[]>([]);

  const toggle = (i: number) =>
    setFlipped((prev) => {
      const next = [...prev];
      next[i] = !next[i];
      return next;
    });

  return (
    <Section id="projects" aria-labelledby="projects-title">
      <Title id="projects-title">Featured Projects</Title>
      <Subtitle>Few project featured by me</Subtitle>
      <Line aria-hidden="true" />

      <Grid className="project-gallery">
        {PROJECTS.map((p, i) => (
          <Card key={p.name} data-flipped={!!flipped[i]}>
            <Face className="front">
              <Thumb src={p.img} alt={p.name} loading="lazy" />
              <Content>
                <h3>{p.name}</h3>
              </Content>
              <Buttons>
                {p.linkGit && (
                  <a href={p.linkGit} target="_blank" rel="noopener noreferrer">
                    <Btn variant="outline">Github</Btn>
                  </a>
                )}
                <Btn onClick={() => toggle(i)}>Description</Btn>
              </Buttons>
            </Face>

            <Face className="back">
              <Info>
                <p>
                  <b>Description:</b> {p.des}
                </p>
                <p>
                  <b>Member:</b> {p.member}
                </p>
                <p>
                  <b>My role:</b> {p.role}
                </p>
                <p>
                  <b>Result:</b> {p.result}
                </p>
              </Info>

              <TechList aria-label="Technologies">
                {p.tech.map((t, k) => (
                  <li key={k}>
                    <Dot /> <span>{t.nameTech}</span>
                  </li>
                ))}
              </TechList>

              <Buttons>
                {p.linkLive ? (
                  <a href={p.linkLive} target="_blank" rel="noopener noreferrer">
                    <Btn variant="outline">Live</Btn>
                  </a>
                ) : (
                  <Btn variant="ghost" disabled>Live</Btn>
                )}
                <Btn onClick={() => toggle(i)}>Back</Btn>
              </Buttons>
            </Face>
          </Card>
        ))}
      </Grid>
    </Section>
  );
};

export default Projects;

/* ==================== styled ==================== */

const Section = styled.section`
  scroll-margin-top: 80px;
  padding: 56px 0 24px;
`;

const Title = styled.h2`
  display: flex;
  justify-content: center;
  font-size: 35px;
  font-weight: 700;
`;

const Subtitle = styled.p`
  display: flex;
  justify-content: center;
  font-size: 16px;
  font-weight: 500;
  margin-top: 16px;
`;

const Line = styled.div`
  width: 120px;
  height: 3px;
  margin: 16px auto 0;
  background: var(--color-dot, #6c63ff);
  border-radius: 999px;
`;

const Grid = styled.div`
  --card-w: clamp(280px, 31vw, 380px);
  --card-h: 580px;

  width: min(1100px, 92vw);
  margin: 28px auto 0;

  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(var(--card-w), 1fr));
  gap: 22px;
`;

const Card = styled.article`
  position: relative;
  height: var(--card-h);
  border-radius: 20px;
  box-shadow: 0 0 20px -2px #cacaca;
  border: 1px solid #e9ecef;
  perspective: 1000px;
  display: flex;
  flex-direction: column;

  .front,
  .back {
    position: absolute;
    inset: 0;
    padding: 16px;
    display: flex;
    flex-direction: column;
    border-radius: inherit;
    background: #fff;
    backface-visibility: hidden;
    height: 100%;
  }

  .back {
    transform: rotateY(180deg);
  }

  &[data-flipped="true"] {
    transform: rotateY(180deg);
  }

  transition: transform 0.6s;
  transform-style: preserve-3d;
`;

const Face = styled.div``;

const Thumb = styled.img`
  width: 100%;
  height: 300px;
  border-radius: 16px;
  object-fit: cover;
  transition: transform 0.5s ease-in-out;
  &:hover { transform: scale(1.06); transform-origin: center; }
`;

const Content = styled.div`
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #111;
  h3 { text-align: center; font-size: 20px; font-weight: 600; margin: 0; }
`;

const Info = styled.div`
  display: grid;
  gap: 8px;
  width: 100%;
  font-size: 16px;
`;

const TechList = styled.ul`
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  gap: 6px;
  li { display: flex; align-items: center; }
  span { margin-left: 10px; font-size: 16px; }
`;

const Dot = styled.span`
  width: 10px; height: 10px; border-radius: 50%; background: #000;
`;

const Buttons = styled.div`
  display: flex;
  justify-content: center;
  gap: 12px;
  margin-top: auto;
  margin-bottom: 0;

  a { text-decoration: none; }
`;

const Btn = styled.button<{ variant?: "outline" | "ghost" }>`
  width: 120px;
  height: 45px;
  border-radius: 25px;
  cursor: pointer;
  font-size: var(--fontSize-button, 15px);
  border: ${({ variant }) => (variant === "outline" ? "2px solid #000" : "none")};
  background: ${({ variant }) => (variant === "ghost" ? "#f1f3f5" : "var(--button-right, #6c63ff)")};
  color: ${({ variant }) => (variant === "outline" ? "#000" : "var(--textbutton-right, #fff)")};
  opacity: ${({ disabled }) => (disabled ? 0.6 : 1)};
`;
